# -*- coding: utf-8 -*-
# py3.8 兼容补丁：模块级 union 常量（future annotations 救不了运行时赋值）
import pathlib
p = pathlib.Path("/root/work/pkg/depth_pro_2/streaming.py")
s = p.read_text()
s = s.replace(
    "Prediction = Mapping[str, torch.Tensor | None]",
    "Prediction = Mapping[str, Optional[torch.Tensor]]")
if "Optional" not in s[:800]:
    s = s.replace("from typing import", "from typing import Optional,", 1)
p.write_text(s)
print("patched streaming.py")
