#!/bin/bash
set -ex
cd /root/work
export HF_ENDPOINT=https://hf-mirror.com

# 1) miniconda py311（清华源）
curl -fsSL https://mirrors.tuna.tsinghua.edu.cn/anaconda/miniconda/Miniconda3-latest-Linux-x86_64.sh -o mc.sh
bash mc.sh -b -p /root/mc
/root/mc/bin/conda create -y -n dp python=3.11
P=/root/mc/envs/dp/bin

# 2) torch cpu（阿里云轮子源）+ 其余依赖（清华 pypi）
$P/pip install -q --no-deps \
  https://mirrors.aliyun.com/pytorch-wheels/cpu/torch-2.4.0%2Bcpu-cp311-cp311-linux_x86_64.whl \
  https://mirrors.aliyun.com/pytorch-wheels/cpu/torchvision-0.19.0%2Bcpu-cp311-cp311-linux_x86_64.whl
$P/pip install -q numpy pillow scipy timm av pillow-heif click huggingface_hub matplotlib oss2 \
  -i https://pypi.tuna.tsinghua.edu.cn/simple

# 3) 权重（Apple CDN）
mkdir -p torch_home/hub/checkpoints
cd torch_home/hub/checkpoints
wget -q https://ml-site.cdn-apple.com/models/depth-pro-2/depthpro2-s-bgcc6f8bg3.pt &
wget -q https://ml-site.cdn-apple.com/models/depth-pro-2/depthpro2-l-tegstu7fim.pt &
wget -q https://ml-site.cdn-apple.com/models/depth-pro-2/depthpro2-fov-ew55zg4kq7.pt &
wait
cd /root/work

# 4) 推理：S + L，1024 长边
export PYTHONPATH=/root/work/depth_pro_2_src TORCH_HOME=/root/work/torch_home
$P/python -m depth_pro_2.cli predict -i input/yuantu.jpg -o output/ -m depthpro2-s --save-npz --save-png16
$P/python -m depth_pro_2.cli predict -i input/yuantu.jpg -o output/ -m depthpro2-l --save-npz --save-png16

# 5) 上传结果
$P/python push_oss.py
echo TASK_DONE
