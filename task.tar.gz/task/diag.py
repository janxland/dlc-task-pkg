# -*- coding: utf-8 -*-
import os, urllib.request, urllib.error, base64, hashlib, hmac, datetime, sys

log_lines = []
def log(*a):
    s = " ".join(str(x) for x in a)
    log_lines.append(s)
    print(s, flush=True)

# 1) GET task 包测试
get_url = os.environ.get("TASK_URL", "")
put_url = os.environ.get("LOG_PUT", "")
try:
    req = urllib.request.Request(get_url)
    with urllib.request.urlopen(req, timeout=60) as r:
        data = r.read()
    log("GET task.tar.gz: status", r.status, "size", len(data))
    open("/tmp/task.tar.gz", "wb").write(data)
except Exception as e:
    log("GET FAILED:", repr(e)[:300])
    data = b""

# 2) 环境信息
log("python:", sys.version)
log("nproc:", os.popen("nproc").read().strip())

# 3) 手写 OSS V1 签名 PUT 日志
body = ("\n".join(log_lines)).encode("utf-8")
try:
    host = "depthpro2-janx-1953654729297796.oss-cn-hangzhou.aliyuncs.com"
    key = "logs/diag.log"
    ak = os.environ["AK_ID"]; sk = os.environ["AK_SEC"]
    date = datetime.datetime.now(datetime.timezone.utc).strftime("%a, %d %b %Y %H:%M:%S GMT")
    ct = "application/octet-stream"
    s2s = "PUT\n\n%s\n%s\n/%s/%s" % (ct, date, "depthpro2-janx-1953654729297796", key)
    sig = base64.b64encode(hmac.new(sk.encode(), s2s.encode(), hashlib.sha1).digest()).decode()
    req = urllib.request.Request("https://%s/%s" % (host, key), data=body, method="PUT")
    req.add_header("Date", date)
    req.add_header("Content-Type", ct)
    req.add_header("Authorization", "OSS %s:%s" % (ak, sig))
    with urllib.request.urlopen(req, timeout=60) as r:
        log("PUT diag.log: status", r.status)
except urllib.error.HTTPError as e:
    log("PUT FAILED:", e.code, e.read()[:300].decode('utf-8','ignore'))
except Exception as e:
    log("PUT FAILED:", repr(e)[:300])
PYEOF
R=/Users/Admin1/Desktop/project/janxland/spatial-scene-android
cd /tmp/dlc_task && tar czf task.tar.gz task && $R/.venv/bin/python - <<'PYEOF'
import oss2
auth = oss2.Auth("LTAI5t5oJjo8sPc4fzA4Md4M", "6iEBzcQ0NRlkdYrAkJaUrE0gmbkHng")
bucket = oss2.Bucket(auth, "https://oss-cn-hangzhou.aliyuncs.com", "depthpro2-janx-1953654729297796")
bucket.put_object_from_file("task/task.tar.gz", "/tmp/dlc_task/task.tar.gz")
open("/tmp/dlc_task/task_url.txt","w").write(bucket.sign_url("GET", "task/task.tar.gz", 4*3600))
open("/tmp/dlc_task/log_put_url3.txt","w").write(bucket.sign_url("PUT", "logs/diag2.log", 3600))
import urllib.request as u
print("GET check:", u.urlopen(bucket.sign_url("GET","task/task.tar.gz",600), timeout=30).status)
PYEOF