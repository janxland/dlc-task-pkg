import os, oss2
auth = oss2.Auth(os.environ["AK_ID"], os.environ["AK_SEC"])
b = oss2.Bucket(auth, "https://oss-cn-hangzhou.aliyuncs.com", "depthpro2-janx-1953654729297796")
b.put_object_from_file("logs/run.log", "/root/work/run.log")
print("log uploaded")
