import os, glob, oss2
auth = oss2.Auth(os.environ["AK_ID"], os.environ["AK_SEC"])
b = oss2.Bucket(auth, "https://oss-cn-hangzhou.aliyuncs.com", "depthpro2-janx-1953654729297796")
for p in glob.glob("output/*"):
    b.put_object_from_file("output/" + os.path.basename(p), p)
    print("pushed", p)
